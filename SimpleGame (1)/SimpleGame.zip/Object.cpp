#include "stdafx.h"
#include "Object.h"



Information * Object::GetInfo()
{
	return m_Info;
}
Object::Object()
{
}

Object::~Object()
{
}



