#pragma once
#define MAX_OBJECTS_COUNT 10

#include"Object.h"
class Renderer;



class SceneMgr
{
private:
	Object* m_Object;
	Renderer* m_Renderer;
	list<Object*> lObject;


public:
	SceneMgr();
	~SceneMgr();
	void update(float);
	void Renderer();
	void Collision();
//	void AddActorObject(int, int, OBJECT_TYPE type);

};




 
